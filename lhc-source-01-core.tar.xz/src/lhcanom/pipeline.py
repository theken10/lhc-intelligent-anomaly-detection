import argparse
import json
import os
import platform
import time

import joblib
import numpy as np
import pandas as pd
import torch
import yaml

from . import benchmark, eda, explain, ingest, robustness
from .metrics import evaluate, threshold_at_fpr
from .models import AutoEncoder, IForest, XGB
from .preprocess import FEATURES, Preprocessor, split, validate
from .scoring import ScoreScaler


def run(cfg, outdir="results", skip_benchmark=False):
    t0 = time.time()
    fig_dir = os.path.join(outdir, "figures")
    model_dir = os.path.join(outdir, "models")
    os.makedirs(fig_dir, exist_ok=True)
    os.makedirs(model_dir, exist_ok=True)
    seed = cfg["seed"]

    print("[1/7] loading events")
    raw = ingest.load_events(cfg)
    df, val_report = validate(raw)
    print("     ", val_report)

    has_labels = bool((df["label"] >= 0).all() and df["label"].sum() > 0)

    print("[2/7] exploratory plots")
    eda.run_eda(df, fig_dir)

    tr, va, te = split(df, cfg["split"]["train"], cfg["split"]["val"], seed=seed)
    prep = Preprocessor().fit(tr)
    Xtr, Xva, Xte = prep.transform(tr), prep.transform(va), prep.transform(te)
    ytr, yva, yte = tr["label"].to_numpy(), va["label"].to_numpy(), te["label"].to_numpy()

    print("[3/7] training models")
    models = {}
    iso = IForest(**cfg["iforest"], seed=seed).fit(Xtr)
    models[iso.name] = iso

    a = cfg["autoencoder"]
    ae = AutoEncoder(hidden=a["hidden"], latent=a["latent"], epochs=a["epochs"],
                     batch_size=a["batch_size"], lr=a["lr"], patience=a["patience"], seed=seed)
    ae.fit(Xtr, Xval=Xva)
    models[ae.name] = ae
    print(f"      autoencoder stopped after {len(ae.history)} epochs, "
          f"val loss {ae.history[-1][2]:.4f}")

    xgb = None
    if has_labels:
        xgb = XGB(**cfg["xgboost"], seed=seed).fit(Xtr, ytr, Xva, yva)
        models[xgb.name] = xgb

    print("[4/7] scoring + metrics")
    fpr = cfg["target_fpr"]
    thresholds, scalers, test_scores = {}, {}, {}
    for name, m in models.items():
        sva = m.score(Xva)
        if m.kind == "unsupervised":
            # no labels used: just flag the top `fpr` of the validation events
            thr = threshold_at_fpr(sva, fpr)
        else:
            thr = threshold_at_fpr(sva[yva == 0], fpr)
        thresholds[name] = thr
        scalers[name] = ScoreScaler().fit(sva)
        test_scores[name] = m.score(Xte)

    metrics_rows = []
    if has_labels:
        for name, m in models.items():
            r = evaluate(yte, test_scores[name], thresholds[name])
            r.update(model=name, type=m.kind)
            metrics_rows.append(r)
        metrics = pd.DataFrame(metrics_rows).set_index("model")
        metrics.to_csv(os.path.join(outdir, "metrics.csv"))
        print(metrics[["type", "roc_auc", "precision", "recall", "f1",
                       "false_positive_rate", "tpr_at_1pct_fpr"]].round(3).to_string())

    # score table for the dashboard
    out = te.copy()
    out.insert(0, "event_id", np.arange(len(out)))
    for name in models:
        out[f"score_{name}"] = test_scores[name]
        out[f"norm_{name}"] = scalers[name](test_scores[name])
        out[f"flag_{name}"] = (test_scores[name] >= thresholds[name]).astype(int)
    out.to_csv(os.path.join(outdir, "scores_test.csv"), index=False)

    print("[5/7] explanations")
    bg_n = min(cfg["explain"]["background_sample"], len(Xte))
    bg = Xte[np.random.default_rng(seed).choice(len(Xte), bg_n, replace=False)]
    explain.global_importance(iso, xgb, bg, fig_dir)
    expl = explain.explain_events(te, Xte, ae, iso, cfg["explain"]["top_events"])
    expl["event_id"] = expl["row"]
    expl.drop(columns="row").to_csv(os.path.join(outdir, "explanations.csv"), index=False)

    if has_labels:
        print("[6/7] robustness")
        rob = robustness.run(models, prep, thresholds, te,
                             jes_values=[0.90, 0.95, 1.05, 1.10],
                             pileup_values=[0.5, 1, 2, 4], target_fpr=fpr, seed=seed)
        rob.to_csv(os.path.join(outdir, "robustness.csv"), index=False)
    else:
        print("[6/7] robustness skipped (needs labels)")

    if not skip_benchmark:
        print("[7/7] benchmarks")
        b = cfg["benchmark"]
        inf = benchmark.inference_benchmark(models, Xte, b["batch_sizes"], b["repeats"])
        inf.to_csv(os.path.join(outdir, "benchmark_inference.csv"), index=False)
        gpu_df, devices = benchmark.cpu_vs_gpu(ae, Xte, b["batch_sizes"], b["repeats"])
        gpu_df.to_csv(os.path.join(outdir, "benchmark_cpu_gpu.csv"), index=False)
        if has_labels:
            sizes = sorted({s for s in b["dataset_sizes"] if s < len(tr)} | {len(tr)})
            sc = benchmark.dataset_size_scaling(cfg, prep, tr, va, te, sizes)
            sc.to_csv(os.path.join(outdir, "benchmark_dataset_size.csv"), index=False)
    else:
        devices = ["cpu"]

    joblib.dump({"prep": prep, "iforest": iso, "xgb": xgb, "thresholds": thresholds},
                os.path.join(model_dir, "sklearn_models.joblib"))
    if ae.net is not None:
        torch.save(ae.net.state_dict(), os.path.join(model_dir, "autoencoder.pt"))
    pd.DataFrame(ae.history, columns=["epoch", "train_loss", "val_loss"]).to_csv(
        os.path.join(outdir, "ae_training_curve.csv"), index=False)

    info = {
        "source": cfg["source"],
        "has_labels": has_labels,
        "n_events_after_validation": len(df),
        "n_train": len(tr), "n_val": len(va), "n_test": len(te),
        "validation_report": val_report,
        "thresholds": thresholds,
        "target_fpr": fpr,
        "devices_benchmarked": devices,
        "cuda_available": torch.cuda.is_available(),
        "python": platform.python_version(),
        "torch": torch.__version__,
        "total_seconds": round(time.time() - t0, 1),
    }
    with open(os.path.join(outdir, "run_info.json"), "w") as f:
        json.dump(info, f, indent=2)
    print(f"done in {info['total_seconds']}s -> {outdir}/")
    return info


def main():
    ap = argparse.ArgumentParser(description="LHC anomaly detection pipeline")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--out", default="results")
    ap.add_argument("--skip-benchmark", action="store_true")
    args = ap.parse_args()
    with open(args.config) as f:
        cfg = yaml.safe_load(f)
    run(cfg, args.out, args.skip_benchmark)


if __name__ == "__main__":
    main()
