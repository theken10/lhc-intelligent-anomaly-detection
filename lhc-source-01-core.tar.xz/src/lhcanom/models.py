import time

import numpy as np
import torch
from sklearn.ensemble import IsolationForest
from torch import nn
from xgboost import XGBClassifier


class IForest:
    name = "isolation_forest"
    kind = "unsupervised"

    def __init__(self, n_estimators=300, max_samples=1024, seed=0):
        self.m = IsolationForest(n_estimators=n_estimators, max_samples=max_samples,
                                 random_state=seed, n_jobs=-1)

    def fit(self, X, y=None, Xval=None, yval=None):
        self.m.fit(X)
        return self

    def score(self, X):
        # sklearn: higher = more normal, so flip it
        return -self.m.score_samples(X)


class XGB:
    name = "xgboost"
    kind = "supervised"

    def __init__(self, n_estimators=300, max_depth=5, learning_rate=0.08, seed=0, device="cpu"):
        self.params = dict(n_estimators=n_estimators, max_depth=max_depth,
                           learning_rate=learning_rate, subsample=0.8, colsample_bytree=0.8,
                           random_state=seed, tree_method="hist", device=device,
                           eval_metric="aucpr", early_stopping_rounds=20, n_jobs=-1)
        self.m = None

    def fit(self, X, y, Xval, yval):
        pos = max(int((y == 1).sum()), 1)
        spw = (len(y) - pos) / pos      # classes are very imbalanced
        self.m = XGBClassifier(scale_pos_weight=spw, **self.params)
        self.m.fit(X, y, eval_set=[(Xval, yval)], verbose=False)
        return self

    def score(self, X):
        return self.m.predict_proba(X)[:, 1]


class _AENet(nn.Module):
    def __init__(self, n_in, hidden, latent):
        super().__init__()
        enc, last = [], n_in
        for h in hidden:
            enc += [nn.Linear(last, h), nn.ReLU()]
            last = h
        enc.append(nn.Linear(last, latent))
        dec, last = [], latent
        for h in reversed(hidden):
            dec += [nn.Linear(last, h), nn.ReLU()]
            last = h
        dec.append(nn.Linear(last, n_in))
        self.enc = nn.Sequential(*enc)
        self.dec = nn.Sequential(*dec)

    def forward(self, x):
        return self.dec(self.enc(x))


class AutoEncoder:
    name = "autoencoder"
    kind = "unsupervised"

    def __init__(self, hidden=(32, 16), latent=6, epochs=60, batch_size=512, lr=1e-3,
                 patience=8, seed=0, device="cpu"):
        self.hidden, self.latent = list(hidden), latent
        self.epochs, self.bs, self.lr, self.patience = epochs, batch_size, lr, patience
        self.seed = seed
        self.device = torch.device(device)
        self.net = None
        self.history = []

    def fit(self, X, y=None, Xval=None, yval=None):
        torch.manual_seed(self.seed)
        self.net = _AENet(X.shape[1], self.hidden, self.latent).to(self.device)
        opt = torch.optim.Adam(self.net.parameters(), lr=self.lr)
        loss_fn = nn.MSELoss()
        Xt = torch.from_numpy(X).to(self.device)
        Xv = torch.from_numpy(Xval).to(self.device) if Xval is not None else None

        best, best_state, bad = np.inf, None, 0
        for ep in range(self.epochs):
            self.net.train()
            perm = torch.randperm(len(Xt), device=self.device)
            tot = 0.0
            for i in range(0, len(Xt), self.bs):
                b = Xt[perm[i:i + self.bs]]
                opt.zero_grad()
                loss = loss_fn(self.net(b), b)
                loss.backward()
                opt.step()
                tot += loss.item() * len(b)
            tr_loss = tot / len(Xt)

            va_loss = tr_loss
            if Xv is not None:
                self.net.eval()
                with torch.no_grad():
                    va_loss = loss_fn(self.net(Xv), Xv).item()
            self.history.append((ep + 1, tr_loss, va_loss))

            if va_loss < best - 1e-5:
                best, bad = va_loss, 0
                best_state = {k: v.detach().clone() for k, v in self.net.state_dict().items()}
            else:
                bad += 1
                if bad >= self.patience:
                    break
        if best_state is not None:
            self.net.load_state_dict(best_state)
        self.net.eval()
        return self

    @torch.no_grad()
    def _recon_err(self, X, bs=16384):
        self.net.eval()
        out = []
        for i in range(0, len(X), bs):
            b = torch.from_numpy(X[i:i + bs]).to(self.device)
            out.append(((self.net(b) - b) ** 2).cpu().numpy())
        return np.concatenate(out) if out else np.zeros((0, X.shape[1]))

    def score(self, X):
        return self._recon_err(X).mean(axis=1)

    def feature_errors(self, X):
        """per-feature squared error, used for the explanation part"""
        return self._recon_err(X)

    def to(self, device):
        self.device = torch.device(device)
        self.net.to(self.device)
        return self
