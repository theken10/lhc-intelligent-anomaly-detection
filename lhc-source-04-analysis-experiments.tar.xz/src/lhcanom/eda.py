import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .preprocess import FEATURES


def _save(fig, outdir, name):
    os.makedirs(outdir, exist_ok=True)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, name), dpi=130)
    plt.close(fig)


def run_eda(df, outdir):
    labelled = df["label"].isin([0, 1]).all() and df["label"].sum() > 0

    # energy-like distributions, log y because the spectrum falls fast
    energy = ["jet1_pt", "jet2_pt", "ht", "met", "dijet_mass", "dimuon_mass"]
    fig, axes = plt.subplots(2, 3, figsize=(13, 7))
    for ax, c in zip(axes.ravel(), energy):
        x = df[c][df[c] > 0]
        bins = np.linspace(0, np.percentile(x, 99.8), 70)
        ax.hist(x, bins=bins, histtype="stepfilled", alpha=0.6, label="all events")
        if labelled:
            xa = df.loc[df["label"] == 1, c]
            xa = xa[xa > 0]
            ax.hist(xa, bins=bins, histtype="step", linewidth=1.6, color="crimson",
                    label="injected anomalies")
        ax.set_yscale("log")
        ax.set_xlabel(f"{c} [GeV]")
        ax.set_ylabel("events")
    axes[0, 0].legend(fontsize=8)
    fig.suptitle("Energy distributions")
    _save(fig, outdir, "eda_energy.png")

    # object multiplicities and angles
    fig, axes = plt.subplots(1, 4, figsize=(15, 3.6))
    for ax, c in zip(axes, ["n_jets", "n_muons", "jet1_eta", "mu1_eta"]):
        x = df[c]
        if c.startswith("n_"):
            vals = np.arange(0, int(x.max()) + 2)
            ax.hist(x, bins=vals - 0.5)
        else:
            ax.hist(x[x != 0], bins=60)
        ax.set_yscale("log")
        ax.set_xlabel(c)
    _save(fig, outdir, "eda_multiplicity_angles.png")

    # correlations
    corr = df[FEATURES].corr().to_numpy()
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(FEATURES)))
    ax.set_yticks(range(len(FEATURES)))
    ax.set_xticklabels(FEATURES, rotation=90, fontsize=8)
    ax.set_yticklabels(FEATURES, fontsize=8)
    fig.colorbar(im)
    ax.set_title("Feature correlations")
    _save(fig, outdir, "eda_correlation.png")

    summary = df[FEATURES].describe().T
    summary.to_csv(os.path.join(outdir, "feature_summary.csv"))
    return summary
