import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap

from .preprocess import FEATURES


def _top_str(vals, X_row, k=3):
    idx = np.argsort(-vals)[:k]
    return ", ".join(f"{FEATURES[i]}(z={X_row[i]:+.1f})" for i in idx)


def global_importance(iforest, xgb, X_bg, outdir):
    """mean |SHAP| for IF and (if trained) XGBoost on a background sample"""
    os.makedirs(outdir, exist_ok=True)
    rows = {}

    sv_if = shap.TreeExplainer(iforest.m).shap_values(X_bg)
    rows["isolation_forest"] = np.abs(sv_if).mean(0)
    if xgb is not None:
        sv_x = shap.TreeExplainer(xgb.m).shap_values(X_bg)
        rows["xgboost"] = np.abs(sv_x).mean(0)
        plt.figure()
        shap.summary_plot(sv_x, X_bg, feature_names=FEATURES, show=False, max_display=14)
        plt.title("XGBoost SHAP summary")
        plt.tight_layout()
        plt.savefig(os.path.join(outdir, "shap_xgboost.png"), dpi=130)
        plt.close()

    imp = pd.DataFrame(rows, index=FEATURES)
    imp.to_csv(os.path.join(outdir, "shap_importance.csv"))

    fig, axes = plt.subplots(1, len(rows), figsize=(6 * len(rows), 5), squeeze=False)
    for ax, (name, v) in zip(axes[0], rows.items()):
        order = np.argsort(v)
        ax.barh(np.array(FEATURES)[order], v[order])
        ax.set_title(f"{name}: mean |SHAP|")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "shap_importance.png"), dpi=130)
    plt.close()
    return imp


def explain_events(df_test, X_test, ae, iforest, n_top=150):
    """
    For the n_top most anomalous events (by autoencoder score) say which features
    drove it. AE: share of reconstruction error. IF: most negative SHAP values
    (negative pushes the sample towards 'anomalous').
    """
    ae_scores = ae.score(X_test)
    top = np.argsort(-ae_scores)[:n_top]
    Xt = X_test[top]

    err = ae.feature_errors(Xt)
    sv = shap.TreeExplainer(iforest.m).shap_values(Xt)

    rows = []
    for j, i in enumerate(top):
        rows.append({
            "row": int(i),
            "ae_score": float(ae_scores[i]),
            "ae_main_features": _top_str(err[j], Xt[j]),
            "iforest_main_features": _top_str(-sv[j], Xt[j]),
            "label": int(df_test["label"].iloc[i]),
            "kind": df_test["kind"].iloc[i],
        })
    return pd.DataFrame(rows)
