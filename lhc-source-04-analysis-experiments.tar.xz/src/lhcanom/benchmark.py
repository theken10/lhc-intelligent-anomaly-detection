import time

import numpy as np
import pandas as pd
import psutil
import torch
from sklearn.metrics import roc_auc_score

from . import synth
from .models import AutoEncoder, IForest, XGB


def _timed(fn, repeats, min_window=0.5):
    """
    returns (median seconds per call, cpu utilisation % of the process, rss MB)
    Very fast calls are repeated until ~min_window seconds have passed, otherwise
    the cpu counters are too coarse to say anything.
    """
    proc = psutil.Process()
    fn()  # warm up
    times = []
    c0, w0 = sum(proc.cpu_times()[:2]), time.perf_counter()
    while len(times) < repeats or (time.perf_counter() - w0) < min_window:
        t = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t)
        if len(times) >= 20000:
            break
    c1, w1 = sum(proc.cpu_times()[:2]), time.perf_counter()
    cpu_pct = 100.0 * (c1 - c0) / max(w1 - w0, 1e-9)   # >100 means several cores busy
    return float(np.median(times)), cpu_pct, proc.memory_info().rss / 1e6


def inference_benchmark(models, X, batch_sizes, repeats=5):
    rows = []
    for name, m in models.items():
        for bs in batch_sizes:
            reps = int(np.ceil(bs / len(X)))
            xb = np.tile(X, (reps, 1))[:bs] if reps > 1 else X[:bs]
            t, cpu, rss = _timed(lambda: m.score(xb), repeats)
            rows.append({"model": name, "device": "cpu", "batch_size": bs,
                         "latency_ms_per_batch": t * 1e3,
                         "latency_us_per_event": t * 1e6 / bs,
                         "events_per_sec": bs / t,
                         "cpu_util_pct": cpu, "rss_mb": rss})
    return pd.DataFrame(rows)


def cpu_vs_gpu(ae, X, batch_sizes, repeats=5):
    """autoencoder on cpu and, if there is a cuda device, on gpu"""
    rows = []
    devices = ["cpu"] + (["cuda"] if torch.cuda.is_available() else [])
    for dev in devices:
        ae.to(dev)
        for bs in batch_sizes:
            reps = int(np.ceil(bs / len(X)))
            xb = np.tile(X, (reps, 1))[:bs] if reps > 1 else X[:bs]

            def run():
                ae.score(xb)
                if dev == "cuda":
                    torch.cuda.synchronize()
            t, cpu, _ = _timed(run, repeats)
            rows.append({"device": dev, "batch_size": bs, "latency_ms_per_batch": t * 1e3,
                         "events_per_sec": bs / t, "cpu_util_pct": cpu})
    ae.to("cpu")
    return pd.DataFrame(rows), devices


def dataset_size_scaling(cfg, prep, train_df, val_df, test_df, sizes):
    """train on growing subsets, evaluate on the same test set"""
    Xva = prep.transform(val_df)
    yva = val_df["label"].to_numpy()
    Xte = prep.transform(test_df)
    yte = test_df["label"].to_numpy()
    rows = []
    for n in sizes:
        sub = train_df.sample(n=n, random_state=0) if n < len(train_df) else train_df
        Xs = prep.transform(sub)
        ys = sub["label"].to_numpy()
        builders = {
            "isolation_forest": lambda: IForest(**cfg["iforest"], seed=cfg["seed"]),
            "autoencoder": lambda: AutoEncoder(
                hidden=cfg["autoencoder"]["hidden"], latent=cfg["autoencoder"]["latent"],
                epochs=min(cfg["autoencoder"]["epochs"], 30), batch_size=cfg["autoencoder"]["batch_size"],
                lr=cfg["autoencoder"]["lr"], patience=cfg["autoencoder"]["patience"], seed=cfg["seed"]),
            "xgboost": lambda: XGB(**cfg["xgboost"], seed=cfg["seed"]),
        }
        for name, build in builders.items():
            m = build()
            t = time.perf_counter()
            m.fit(Xs, ys, Xva, yva)
            fit_s = time.perf_counter() - t
            s = m.score(Xte)
            rows.append({"train_size": len(sub), "model": name, "fit_seconds": fit_s,
                         "roc_auc": roc_auc_score(yte, s)})
            print(f"  size={len(sub):>6} {name:<17} fit {fit_s:6.1f}s  auc {rows[-1]['roc_auc']:.3f}")
    return pd.DataFrame(rows)
