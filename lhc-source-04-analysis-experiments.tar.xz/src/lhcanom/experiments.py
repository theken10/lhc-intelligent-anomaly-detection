"""
Extra experiments that stress the models on purpose (the main pipeline run is the easy case):

  generalisation : train on 4 "seen" anomaly kinds, test on seen kinds, on 2 completely
                   unseen kinds, and on data from a generator with different background
                   parameters. Repeated over several seeds, reported as mean +- std.
  contamination  : train on normal-only data vs data with 1% / 5% anomalies mixed in.
  difficulty     : sweep how strongly anomalies differ from normal events (min_strength).

All numbers are on synthetic data, with labels used ONLY for evaluation (and for XGBoost
training, which is supervised by definition).
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from . import synth
from .metrics import threshold_at_fpr, tpr_at_fpr
from .models import AutoEncoder, IForest, XGB
from .preprocess import Preprocessor

# a background that differs from the training generator: harder jets, more MET, fewer Z events
SHIFTED_PARAMS = {"jet_pt_scale": 49.0, "jet_mult_mean": 2.7, "met_scale": 27.0, "z_fraction": 0.30}


def _fit(cfg, df_tr, df_va, which, seed, ae_epochs):
    prep = Preprocessor().fit(df_tr)
    Xtr, Xva = prep.transform(df_tr), prep.transform(df_va)
    ytr, yva = df_tr["label"].to_numpy(), df_va["label"].to_numpy()
    models = {}
    if "iforest" in which:
        models["isolation_forest"] = IForest(**cfg["iforest"], seed=seed).fit(Xtr)
    if "ae" in which:
        a = cfg["autoencoder"]
        models["autoencoder"] = AutoEncoder(hidden=a["hidden"], latent=a["latent"], epochs=ae_epochs,
                                            batch_size=a["batch_size"], lr=a["lr"],
                                            patience=a["patience"], seed=seed).fit(Xtr, Xval=Xva)
    if "xgb" in which:
        models["xgboost"] = XGB(**cfg["xgboost"], seed=seed).fit(Xtr, ytr, Xva, yva)
    # nominal thresholds, chosen on validation data like in the main pipeline
    thr = {}
    for n, m in models.items():
        sva = m.score(Xva)
        thr[n] = threshold_at_fpr(sva, 0.01) if m.kind == "unsupervised" else \
            threshold_at_fpr(sva[yva == 0], 0.01)
    return prep, models, thr


def _eval(prep, models, thr, df_te):
    X = prep.transform(df_te)
    y = df_te["label"].to_numpy()
    rows = {}
    for n, m in models.items():
        s = m.score(X)
        flag = s >= thr[n]
        rows[n] = {
            "roc_auc": roc_auc_score(y, s),
            "avg_precision": average_precision_score(y, s),
            "tpr_at_1pct_fpr": tpr_at_fpr(y, s, 0.01),
            "recall_at_nominal_cut": float(flag[y == 1].mean()),
            "normal_flag_rate": float(flag[y == 0].mean()),
        }
    return rows


def _gen(n, frac, seed, kinds, min_strength=0.15, params=None):
    return synth.generate(n, frac, seed=seed, kinds=kinds, min_strength=min_strength, params=params)


def generalisation(cfg, seeds, n, ae_epochs):
    rows, per_kind = [], []
    seen, unseen = synth.SEEN_KINDS, synth.UNSEEN_KINDS
    for sd in seeds:
        print(f"  generalisation seed {sd}")
        tr = _gen(n, 0.01, sd, seen)
        va = _gen(n // 3, 0.01, sd + 500, seen)
        prep, models, thr = _fit(cfg, tr, va, ["iforest", "ae", "xgb"], sd, ae_epochs)
        tests = {
            "seen kinds": _gen(n // 2, 0.02, sd + 1000, seen),
            "UNSEEN kinds": _gen(n // 2, 0.02, sd + 2000, unseen),
            "seen, shifted background": _gen(n // 2, 0.02, sd + 3000, seen, params=SHIFTED_PARAMS),
            "UNSEEN, shifted background": _gen(n // 2, 0.02, sd + 4000, unseen, params=SHIFTED_PARAMS),
        }
        for tname, dte in tests.items():
            for mname, r in _eval(prep, models, thr, dte).items():
                rows.append({"seed": sd, "test": tname, "model": mname, **r})
        # per-category AUC on a mixed test set (each anomaly kind vs the normal events)
        mixed = _gen(n, 0.03, sd + 5000, seen + unseen)
        X = prep.transform(mixed)
        for mname, m in models.items():
            s = m.score(X)
            normal = mixed["label"].to_numpy() == 0
            for k in seen + unseen:
                sel = (mixed["kind"] == k).to_numpy()
                y = np.r_[np.zeros(normal.sum()), np.ones(sel.sum())]
                per_kind.append({"seed": sd, "model": mname, "kind": k,
                                 "seen_in_training": k in seen,
                                 "roc_auc": roc_auc_score(y, np.r_[s[normal], s[sel]])})
    return pd.DataFrame(rows), pd.DataFrame(per_kind)


def contamination(cfg, seeds, n, ae_epochs, fracs=(0.0, 0.01, 0.05)):
    rows = []
    seen, unseen = synth.SEEN_KINDS, synth.UNSEEN_KINDS
    for sd in seeds:
        print(f"  contamination seed {sd}")
        va = _gen(n // 3, 0.0, sd + 500, seen)                # clean validation set for early stopping
        te_seen = _gen(n // 2, 0.02, sd + 1000, seen)
        te_unseen = _gen(n // 2, 0.02, sd + 2000, unseen)
        for f in fracs:
            tr = _gen(n, f, sd, seen)
            prep, models, thr = _fit(cfg, tr, va, ["iforest", "ae"], sd, ae_epochs)
            for tname, dte in [("seen kinds", te_seen), ("UNSEEN kinds", te_unseen)]:
                for mname, r in _eval(prep, models, thr, dte).items():
                    rows.append({"seed": sd, "train_anomaly_fraction": f, "test": tname,
                                 "model": mname, **r})
    return pd.DataFrame(rows)


def difficulty(cfg, seeds, n, ae_epochs, strengths=(0.0, 0.15, 0.4, 0.7)):
    rows = []
    seen = synth.SEEN_KINDS
    for sd in seeds:
        print(f"  difficulty seed {sd}")
        for ms in strengths:
            tr = _gen(n, 0.01, sd, seen, min_strength=ms)
            va = _gen(n // 3, 0.01, sd + 500, seen, min_strength=ms)
            te = _gen(n // 2, 0.02, sd + 1000, seen, min_strength=ms)
            prep, models, thr = _fit(cfg, tr, va, ["iforest", "ae", "xgb"], sd, ae_epochs)
            for mname, r in _eval(prep, models, thr, te).items():
                rows.append({"seed": sd, "min_strength": ms, "model": mname, **r})
    return pd.DataFrame(rows)


def mean_std(df, by, cols=("roc_auc", "tpr_at_1pct_fpr", "normal_flag_rate")):
    g = df.groupby(by)[list(cols)].agg(["mean", "std"]).round(3)
    g.columns = [f"{a}_{b}" for a, b in g.columns]
    return g.reset_index()


def run_stage(cfg, stage, outdir="results/experiments", seeds=None, n=60000, ae_epochs=40):
    """stage: generalisation | contamination | difficulty | summary  (each saves csv files)"""
    os.makedirs(outdir, exist_ok=True)
    seeds = seeds or [1, 2, 3, 4, 5]
    if stage == "generalisation":
        gen, per_kind = generalisation(cfg, seeds, n, ae_epochs)
        gen.to_csv(os.path.join(outdir, "generalisation_runs.csv"), index=False)
        per_kind.to_csv(os.path.join(outdir, "per_kind_runs.csv"), index=False)
    elif stage == "contamination":
        contamination(cfg, seeds, n, ae_epochs).to_csv(
            os.path.join(outdir, "contamination_runs.csv"), index=False)
    elif stage == "difficulty":
        difficulty(cfg, seeds[:3], n, ae_epochs).to_csv(
            os.path.join(outdir, "difficulty_runs.csv"), index=False)
    elif stage == "summary":
        return summarise(outdir)
    else:
        raise ValueError(stage)


def summarise(outdir):
    rd = lambda f: pd.read_csv(os.path.join(outdir, f))
    s1 = mean_std(rd("generalisation_runs.csv"), ["test", "model"])
    s1.to_csv(os.path.join(outdir, "generalisation_summary.csv"), index=False)
    pk = rd("per_kind_runs.csv").groupby(["kind", "seen_in_training", "model"])["roc_auc"] \
        .agg(["mean", "std"]).round(3).reset_index()
    pk.to_csv(os.path.join(outdir, "per_kind_auc.csv"), index=False)
    s2 = mean_std(rd("contamination_runs.csv"), ["test", "model", "train_anomaly_fraction"])
    s2.to_csv(os.path.join(outdir, "contamination_summary.csv"), index=False)
    s3 = mean_std(rd("difficulty_runs.csv"), ["min_strength", "model"])
    s3.to_csv(os.path.join(outdir, "difficulty_summary.csv"), index=False)
    _plots(s1, pk, s2, s3, outdir)
    return s1, pk, s2, s3


def _plots(s1, pk, s2, s3, outdir):
    models = ["isolation_forest", "autoencoder", "xgboost"]
    tests = list(s1["test"].unique())
    fig, ax = plt.subplots(figsize=(10, 4.5))
    w = 0.26
    for i, m in enumerate(models):
        d = s1[s1.model == m].set_index("test").loc[tests]
        ax.bar(np.arange(len(tests)) + (i - 1) * w, d["roc_auc_mean"], w, yerr=d["roc_auc_std"].fillna(0),
               label=m, capsize=3)
    ax.set_xticks(range(len(tests)))
    ax.set_xticklabels(tests, rotation=12)
    ax.set_ylim(0.4, 1.02)
    ax.axhline(0.5, color="grey", lw=0.8, ls="--")
    ax.set_ylabel("ROC-AUC (mean +- std, 5 seeds)")
    ax.set_title("Generalisation: models trained on 4 anomaly kinds only")
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "generalisation.png"), dpi=130)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for ax, t in zip(axes, ["seen kinds", "UNSEEN kinds"]):
        for m in ["isolation_forest", "autoencoder"]:
            d = s2[(s2.test == t) & (s2.model == m)].sort_values("train_anomaly_fraction")
            ax.errorbar(d["train_anomaly_fraction"] * 100, d["roc_auc_mean"], d["roc_auc_std"].fillna(0),
                        marker="o", capsize=3, label=m)
        ax.set_xlabel("anomalies in training data [%]")
        ax.set_ylabel("ROC-AUC")
        ax.set_title(f"test: {t}")
        ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "contamination.png"), dpi=130)
    plt.close(fig)
