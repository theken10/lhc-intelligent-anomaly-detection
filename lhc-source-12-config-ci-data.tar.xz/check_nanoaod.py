import sys
sys.path.insert(0, "src")
from lhcanom.nanoaod_check import main

sys.exit(main())
