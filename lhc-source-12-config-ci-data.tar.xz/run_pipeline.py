import sys
sys.path.insert(0, "src")
from lhcanom.pipeline import main

main()
