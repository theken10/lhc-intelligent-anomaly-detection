# Getting real CMS Open Data

The pipeline reads CMS **NanoAOD** files (flat ROOT files with an `Events` tree).

1. Go to the CERN Open Data Portal (opendata.cern.ch) and search for CMS NanoAOD
   datasets, e.g. a 2016 primary dataset like DoubleMuon or JetHT. Pick one and open its record page.
2. Download one or two `.root` files from the record page (a single file is a few GB,
   so start with one). They can also be streamed with xrootd urls
   (`root://eospublic.cern.ch//eos/opendata/...`) since uproot accepts those.
3. Put the files in this folder and edit `config.yaml`:

```yaml
source: nanoaod
nanoaod:
  files: ["data/*.root"]
  max_events: 500000
```

4. **First** check the file: `python check_nanoaod.py data/yourfile.root --score`.
   It verifies that the required branches exist, that features are valid, how empty collections look,
   whether the dimuon mass shows a Z peak (for muon datasets) and that model scores are finite and sensible.
   It writes `nanoaod_check_report.json`; paste the PASS/WARN lines into the README status section.
5. `python run_pipeline.py`

Notes
- Real data has no truth labels, so the pipeline skips XGBoost, supervised metrics and the
  robustness AUCs. The isolation forest and autoencoder still run, and the dashboard shows
  the scores, flagged events and explanations.
- To evaluate on real data properly you would need labelled simulation (MC) samples, e.g. a
  QCD or ttbar NanoAODSIM set plus a signal sample, and then run the same code with labels
  filled in. `ingest.load_events` is the place to add that.
- Branch names used are listed in `src/lhcanom/ingest.py` (`BRANCHES`). If a dataset
  uses different ones the loader will raise a KeyError telling you which.
- I could not download CMS files while building this. The loader was tested on ROOT files written with uproot
  from synthetic events (`tests/test_ingest.py`, `tests/test_nanoaod_roundtrip.py`), not on a real CMS file.
