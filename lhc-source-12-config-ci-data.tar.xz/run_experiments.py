import argparse
import sys

import yaml

sys.path.insert(0, "src")
from lhcanom import experiments

ap = argparse.ArgumentParser()
ap.add_argument("--config", default="config.yaml")
ap.add_argument("--stage", default="all",
                help="generalisation | contamination | difficulty | summary | all")
ap.add_argument("--out", default="results/experiments")
ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
ap.add_argument("--n", type=int, default=60000, help="training events per run")
ap.add_argument("--ae-epochs", type=int, default=40)
args = ap.parse_args()

cfg = yaml.safe_load(open(args.config))
stages = ["generalisation", "contamination", "difficulty", "summary"] if args.stage == "all" else [args.stage]
for st in stages:
    print("stage:", st)
    experiments.run_stage(cfg, st, args.out, args.seeds, args.n, args.ae_epochs)
print("done ->", args.out)
