# LHC Intelligent Anomaly Detection

Prototype for finding unusual proton-proton collision events with machine learning, built as an
offline experiment around the CMS NanoAOD format from the CERN Open Data Portal. It is not a trigger
system, see the note at the bottom.

## Read this first: what is and is not verified

| Item | Status |
|---|---|
| Pipeline, models, dashboard, tests on **synthetic** events | works, 17 tests pass |
| NanoAOD loader on a ROOT file written by `uproot` from synthetic events | works: the loader reproduces the directly-built feature table (`tests/test_nanoaod_roundtrip.py`), including events with empty jet/muon collections |
| NanoAOD loader on a **real CMS file** | **NOT done yet.** I could not download CMS data when I built this. Run `python check_nanoaod.py <file> --score` on a real file (see `data/README.md`) and fill in the result below |
| Docker image | Dockerfile written, **not built by me**. `.github/workflows/ci.yml` builds it and runs the tests inside it on every push |
| Results below | synthetic data only. They show how the methods behave on a controlled toy problem, not physics sensitivity |

Result of running the checker on real CMS data: _pending (add dataset name, number of events, and the PASS/WARN lines here)_.

## What it does

1. **Ingest** events from NanoAOD files (uproot + awkward) or from the synthetic generator into one flat table
   (14 features: jet/muon/electron kinematics, HT, MET, dijet and dimuon mass).
2. **Preprocess**: drop NaN/inf/negative-pt/out-of-range-eta rows, log-transform heavy-tailed columns, standard scale, stratified split.
3. **Explore**: energy distributions, multiplicities, correlations (`results/figures/`).
4. **Baselines**: Isolation Forest (unsupervised), XGBoost (supervised).
5. **Autoencoder** (PyTorch, unsupervised): anomaly score = reconstruction error.
6. **Scoring**: raw score per model plus a 0-1 percentile score. Threshold flags the top 1% of validation events.
7. **Explainability**: SHAP for Isolation Forest and XGBoost, per-feature reconstruction error for the autoencoder.
8. **Dashboard** (Streamlit): event stats, scores, model comparison, explanations, performance, robustness, experiments.

Plus: supervised vs unsupervised comparison, CPU vs GPU timing (GPU only if CUDA is present), latency/throughput,
dataset-size scaling, drift tests with threshold re-calibration, and the stress experiments below.

## Run it

```bash
pip install -r requirements.txt
python run_pipeline.py                      # ~1-2 min, writes results/ (needed before the dashboard)
python run_experiments.py                   # generalisation / contamination / difficulty, ~10 min on 1 core
streamlit run app/dashboard.py
pytest -q                                   # 17 tests
python check_nanoaod.py data/file.root --score   # sanity checks for a real NanoAOD file
```

`run_experiments.py --stage generalisation|contamination|difficulty|summary` runs one stage at a time.
The synthetic pipeline and tests do not need `awkward`/`uproot`; only reading ROOT files does.

`results/scores_test.csv` and `results/models/` are not committed (generated, large); `run_pipeline.py` recreates them.

## Layout

```
config.yaml            all settings
run_pipeline.py        main run -> results/
run_experiments.py     stress experiments -> results/experiments/
check_nanoaod.py       sanity checks for a real NanoAOD file
src/lhcanom/           ingest, synth, preprocess, models, scoring, metrics, explain,
                       robustness, benchmark, experiments, nanoaod_check, pipeline
app/dashboard.py       Streamlit app
cpp/invmass.cpp        small C++ invariant-mass tool, cross-checked against python in tests
tests/                 17 tests
.github/workflows/     CI: tests, small pipeline run, docker build + container test
```

## The synthetic data (and why the first version was too easy)

My first generator made anomalies that were obviously different from normal events, and XGBoost got
ROC-AUC 1.000. That was not a bug, it was a toy problem that was too easy, and the model was tested
on the same anomaly categories it was trained on. The generator now works differently:

- Each anomaly is a normal-looking event pushed toward an odd pattern by a random **strength** between
  `min_strength` (0.15) and 1. Weak anomalies sit inside the tails of the normal distributions
  (in a sample with all six categories, about 60% of anomalies had HT below the 99th percentile of normal events).
- 4 **seen** categories (heavy dijet, MET + lepton, high multiplicity, dimuon resonance) and
  2 **unseen** ones (dijet + MET, lepton + high HT) that are used only for testing.
- Background parameters (jet pt slope, multiplicity, MET, Z fraction) can be changed to make an independent
  generator for testing.

It is still a toy: the anomalies are simple, features are independent in ways real events are not,
and there is no detector effect.

## Main run results (120k events, 1% anomalies, test split 24k)

| model | type | ROC-AUC | precision | recall | F1 | FPR | TPR @ 1% FPR |
|---|---|---|---|---|---|---|---|
| Isolation Forest | unsupervised | 0.923 | 0.26 | 0.26 | 0.26 | 0.7% | 0.30 |
| Autoencoder | unsupervised | 0.869 | 0.17 | 0.17 | 0.17 | 0.9% | 0.19 |
| XGBoost | supervised | 0.995 | 0.49 | 0.96 | 0.65 | 1.0% | 0.96 |

Precision is low for every model because with 1% anomalies, even a 1% false-positive rate flags about as many normal events as true anomalies.
XGBoost is trained on labels of the same categories it is tested on here, so this row is the "known signal" ceiling.

## Stress experiments (5 seeds, mean +- std, `results/experiments/`)

Models trained on the 4 seen categories only (60k training events per run).

**Generalisation, ROC-AUC**

| test set | Isolation Forest | Autoencoder | XGBoost |
|---|---|---|---|
| seen categories | 0.923 +- 0.005 | 0.877 +- 0.014 | 0.989 +- 0.002 |
| **unseen** categories | 0.804 +- 0.007 | 0.809 +- 0.032 | 0.922 +- 0.009 |
| seen, different background parameters | 0.926 +- 0.004 | 0.869 +- 0.015 | 0.982 +- 0.003 |
| unseen, different background parameters | 0.816 +- 0.010 | 0.789 +- 0.031 | 0.893 +- 0.006 |

- The supervised model loses a lot on unseen categories: TPR at 1% FPR falls from 0.92 to 0.44. It still
  beats the unsupervised models in AUC here, probably because the unseen categories share features
  (large HT, MET, leptons) with the seen ones. That would be less true for a signal that looks different from all training anomalies.
- The unsupervised models are weaker overall but their performance does not depend on which categories were used for training.
  In absolute terms they are poor on the unseen kinds (TPR at 1% FPR 0.07 and 0.02).
- With the different background parameters, the XGBoost threshold chosen on nominal data flags 3.3% of normal events instead of 1%:
  ranking survives, calibration does not.
- Per-category AUC (vs normal events) is lowest for high-multiplicity events (autoencoder 0.70, Isolation Forest 0.84)
  and dijet + MET (0.76 / 0.75), highest for dimuon resonances (0.97 / 0.99). See `per_kind_auc.csv`.

**Training contamination** (anomalies mixed into the unsupervised training set, validation set kept clean, test = seen categories)

| anomalies in training | Autoencoder AUC | Isolation Forest AUC |
|---|---|---|
| 0% (normal only) | 0.893 +- 0.017 | 0.911 +- 0.007 |
| 1% | 0.877 +- 0.014 | 0.923 +- 0.005 |
| 5% | 0.848 +- 0.016 | 0.908 +- 0.005 |

The autoencoder gets steadily worse as more anomalies are in its training data, as expected. For Isolation Forest the effect is
not monotonic (1% is slightly better than 0%), and I do not have an explanation, so I would not read much into
the small differences. Training on normal-only events needs a trustworthy background sample, e.g. simulation.
Note the main run above trains on the contaminated split, with 1% anomalies in it.

**Difficulty sweep** (3 seeds): as `min_strength` goes from 0 to 0.7, AUC rises from 0.887 to 0.978 (Isolation Forest),
0.856 to 0.922 (autoencoder), 0.956 to 0.999 (XGBoost). Even with anomalies that can look exactly normal (strength 0) no
model is near chance, because the anomalies are still drawn from fixed patterns.

## Drift and threshold calibration

`robustness.csv` / dashboard tab. The test set is shifted (jet energy scale 0.90-1.10; pileup-like extra jets, HT and MET),
and for each shift two thresholds are compared: the one fixed on nominal validation data, and one re-chosen from a
label-free calibration half of the shifted data ("flag the top 1% of what we see"). Evaluation uses the other half.

- Jet energy scale +-10%: almost no effect on anything.
- Pileup-like shift, 4 extra jets on average: the autoencoder's AUC drops from 0.87 to 0.67 and its fixed-threshold false alarm rate goes
  from 0.8% to 17.7%; Isolation Forest's AUC stays about 0.92 but its false alarm rate goes from 0.7% to 2.7%; XGBoost's AUC stays 0.99, false
  alarms rise 0.9% to 3.7%.
- **Re-calibration fixes the false alarm rate (back to about 1%) but cannot fix a broken ranking**: for the autoencoder at this
  shift, recall with a re-calibrated cut is 0.00. For Isolation Forest, the recall with the fixed cut goes *up* (0.26 to 0.47) only because
  many more normal events are flagged.
- A label-free drift monitor (alarm if the overall flag rate exceeds 1.5x its nominal value) fires for the autoencoder from pileup level 0.5,
  for XGBoost and Isolation Forest at the larger pileup levels, and never for the jet energy scale shifts.

**Limitation of the simulation:** the pileup and jet-energy-scale "shifts" are simple edits of the feature table
(`robustness.py`). They are not a detector or pileup simulation: real pileup changes jet reconstruction and
isolation, MET resolution, and trigger behaviour. Treat the numbers as a stress test of the pipeline's behaviour, not as a prediction for CMS.

## Speed (single CPU core, no CUDA here, offline python)

| model | batch 1 | batch 8192 |
|---|---|---|
| Isolation Forest | 17 ms/event (58 events/s) | 57k events/s |
| Autoencoder | 95 us/event | 4.2M events/s |
| XGBoost | 255 us/event | 1.7M events/s |

Dataset-size scaling (5k to 72k training events) is in `benchmark_dataset_size.csv`: Isolation Forest AUC is flat (0.92-0.93)
while the autoencoder improves from 0.80 to 0.85 (capped at 30 epochs there). GPU numbers: `benchmark_cpu_gpu.csv` only has
CPU rows because the machine had no CUDA device. Timings depend on the machine; rerun on yours.

## Limitations

- Synthetic data only so far (see the status table). Real data has no labels, so on it you get scores and flagged events but not
  precision/recall/AUC. Labelled evaluation needs simulation (MC) samples.
- 14 high-level features, no per-particle or calorimeter information.
- Simple pt/eta cuts, no object ID, isolation, trigger selection or pileup corrections.
- Thresholds are chosen on validation data from the same source; real use would need calibration against detector conditions.
- Explanations (SHAP, reconstruction error) say which features drove a score, not what physics process the event is.

## Note on trigger latency

This is an offline prototype on public data, written in python. The latencies above are software inference times
on a general-purpose CPU. They are not comparable to the CERN hardware-level trigger, which works at microsecond-scale
latency on dedicated electronics, and this project does not claim anything about that.

## Data

CMS Open Data: opendata.cern.ch (CERN Open Data Portal), with the CMS research data guides and tutorials there.
Follow the portal's terms of use and cite the datasets you use.
