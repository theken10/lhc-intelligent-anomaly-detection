"""
What happens to the scores when the data drifts a bit, and does re-calibrating the
threshold help?

Two toy drifts: jet energy scale (all jet energies off by a few %) and pileup-like
extra activity. These are crude approximations done on the feature table, NOT a detector
simulation: real pileup changes jet reconstruction, isolation, MET resolution, trigger
rates, etc. Treat the pileup numbers as a stress test for the pipeline, not a prediction.

For every shifted dataset we compare two ways of choosing the cut:
  fixed : the threshold chosen on nominal validation data (what you would deploy)
  recal : threshold re-chosen from a label-free calibration batch of the shifted data,
          i.e. "flag the top X% of what we see now". Calibration events and evaluation
          events are disjoint halves of the shifted test set.
"""
import numpy as np
import pandas as pd
from scipy.stats import ks_2samp
from sklearn.metrics import roc_auc_score

from .metrics import threshold_at_fpr


def apply_jes(df, scale):
    d = df.copy()
    for c in ["jet1_pt", "jet2_pt", "ht", "dijet_mass"]:
        d[c] = d[c] * scale
    return d


def apply_pileup(df, level, seed=0):
    rng = np.random.default_rng(seed)
    d = df.copy()
    extra = rng.poisson(level, len(d))
    d["n_jets"] = d["n_jets"] + extra
    d["ht"] = d["ht"] + extra * rng.exponential(38, len(d))
    d["met"] = d["met"] + rng.rayleigh(4.0 * level + 1e-9, len(d))
    return d


def run(models, prep, thresholds, df_test, jes_values, pileup_values, target_fpr=0.01, seed=0):
    """models: name -> fitted model; thresholds: name -> nominal raw-score cut"""
    y = df_test["label"].to_numpy()
    rng = np.random.default_rng(seed)
    calib = rng.random(len(df_test)) < 0.5       # half for recalibration, half for evaluation
    ev = ~calib

    base_scores = {n: m.score(prep.transform(df_test)) for n, m in models.items()}
    # flag rate on nominal data with the deployed cut, label-free reference for the drift monitor
    base_flag = {n: float((base_scores[n][calib] >= thresholds[n]).mean()) for n in models}
    shifts = [("none", 0.0, df_test)] + \
             [("jes", v, apply_jes(df_test, v)) for v in jes_values] + \
             [("pileup", v, apply_pileup(df_test, v)) for v in pileup_values]

    rows = []
    for kind, val, dshift in shifts:
        X = prep.transform(dshift)
        for name, m in models.items():
            s = m.score(X)
            thr_fixed = thresholds[name]
            thr_recal = threshold_at_fpr(s[calib], target_fpr)     # no labels used
            normal = ev & (y == 0)
            anom = ev & (y == 1)
            nominal_flag_rate_all = float((s[calib] >= thr_fixed).mean())  # observable without labels
            rows.append({
                "shift": kind, "value": val, "model": name,
                "roc_auc": roc_auc_score(y[ev], s[ev]),
                "normal_flag_rate_fixed": float((s[normal] >= thr_fixed).mean()),
                "recall_fixed": float((s[anom] >= thr_fixed).mean()),
                "normal_flag_rate_recal": float((s[normal] >= thr_recal).mean()),
                "recall_recal": float((s[anom] >= thr_recal).mean()),
                "overall_flag_rate_fixed": nominal_flag_rate_all,
                # label-free monitor: alarm if the overall flag rate is >1.5x what it was on nominal data
                "drift_alarm": bool(nominal_flag_rate_all > 1.5 * base_flag[name]),
                "ks_vs_nominal": float(ks_2samp(base_scores[name][y == 0], s[y == 0]).statistic),
            })
    return pd.DataFrame(rows)
