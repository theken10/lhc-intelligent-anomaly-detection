import numpy as np
from sklearn.metrics import (average_precision_score, f1_score, precision_score,
                             recall_score, roc_auc_score, roc_curve)


def threshold_at_fpr(scores_normal_like, fpr):
    """score cut so that `fpr` of the given scores sit above it"""
    return float(np.quantile(scores_normal_like, 1.0 - fpr))


def tpr_at_fpr(y, s, target=0.01):
    fpr, tpr, _ = roc_curve(y, s)
    return float(np.interp(target, fpr, tpr))


def evaluate(y, s, thr):
    """y: 0/1 truth (evaluation only), s: anomaly score, thr: decision threshold"""
    pred = (s >= thr).astype(int)
    out = {
        "precision": precision_score(y, pred, zero_division=0),
        "recall": recall_score(y, pred, zero_division=0),
        "f1": f1_score(y, pred, zero_division=0),
        "roc_auc": roc_auc_score(y, s),
        "avg_precision": average_precision_score(y, s),
        "tpr_at_1pct_fpr": tpr_at_fpr(y, s, 0.01),
    }
    neg = y == 0
    out["false_positive_rate"] = float((pred[neg] == 1).mean()) if neg.any() else float("nan")
    out["threshold"] = float(thr)
    return {k: float(v) for k, v in out.items()}
