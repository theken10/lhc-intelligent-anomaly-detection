"""
Sanity checks for a real (or fake) NanoAOD file before trusting the pipeline on it.

    python check_nanoaod.py data/myfile.root --score

Checks, in order:
  1. file opens, tree exists, all required branches are present
  2. extracted features are valid (NaN/inf, negative pt, eta range)
  3. how empty collections look (events with no jets / no muons ...)
  4. rough physics sanity (jet pt spectrum falls, Z peak in dimuon mass if enough dimuon events)
  5. optional: fit isolation forest + autoencoder on half the events, score the other half,
     check that the scores are finite and that flagged events really are the "big" ones

Prints PASS / WARN / FAIL lines and writes a json report. Nothing here proves the
physics is right, it just catches the obvious ways a pipeline run on real data can go wrong.
"""
import argparse
import json
import sys

import numpy as np

from . import ingest
from .preprocess import FEATURES, Preprocessor, validate


class Report:
    def __init__(self):
        self.lines = []
        self.data = {}

    def add(self, status, msg):
        self.lines.append((status, msg))
        print(f"[{status}] {msg}")

    @property
    def failed(self):
        return any(s == "FAIL" for s, _ in self.lines)


def check_file(path, tree="Events", max_events=100000, score=False, seed=0):
    import uproot

    rep = Report()

    # 1. structure
    try:
        fh = uproot.open(path)
    except Exception as e:
        rep.add("FAIL", f"cannot open {path}: {e}")
        return rep
    with fh:
        if tree not in fh:
            rep.add("FAIL", f"no tree '{tree}', keys: {fh.keys()[:6]}")
            return rep
        t = fh[tree]
        have = set(t.keys())
        n_total = t.num_entries
        rep.data["entries_in_file"] = int(n_total)
        missing = [b for b in ingest.BRANCHES if b not in have]
        if missing:
            near = {m: [h for h in have if h.split("_")[0] == m.split("_")[0]][:5] for m in missing}
            rep.add("FAIL", f"missing branches {missing}; similar names in file: {near}")
            return rep
        rep.add("PASS", f"tree '{tree}' has {n_total:,} entries and all {len(ingest.BRANCHES)} required branches")

    # 2. features
    df = ingest.load_nanoaod([path], tree=tree, max_events=max_events)
    rep.data["events_read"] = len(df)
    clean, vr = validate(df)
    rep.data["validation"] = vr
    drop = vr["rows_dropped"] / max(vr["rows_in"], 1)
    status = "PASS" if drop < 0.001 else ("WARN" if drop < 0.05 else "FAIL")
    rep.add(status, f"validation dropped {vr['rows_dropped']} of {vr['rows_in']} events ({100*drop:.2f}%): {vr}")

    stats = df[FEATURES].describe().T[["min", "mean", "max"]]
    rep.data["feature_ranges"] = stats.round(3).to_dict("index")
    if (df["jet1_pt"] > 13000).any() or (df["met"] > 13000).any():
        rep.add("WARN", "some pt/MET values exceed the 13 TeV beam energy, check units / corrupted events")
    else:
        rep.add("PASS", "pt and MET values are below the beam energy")

    # 3. empty collections
    empt = {
        "no_jets": float((df["n_jets"] == 0).mean()),
        "one_jet": float((df["n_jets"] == 1).mean()),
        "no_muons": float((df["n_muons"] == 0).mean()),
        "fewer_than_2_muons": float((df["n_muons"] < 2).mean()),
        "no_electrons": float((df["n_electrons"] == 0).mean()),
    }
    rep.data["empty_collection_fractions"] = empt
    rep.add("PASS", "empty collections handled (filled with 0): " +
            ", ".join(f"{k}={v:.2f}" for k, v in empt.items()))
    if empt["fewer_than_2_muons"] > 0.98:
        rep.add("WARN", "almost no dimuon events, dimuon_mass is nearly constant 0 for this dataset "
                        "(normal for a jet dataset, but then that feature carries no information)")

    # 4. physics sanity
    j = df.loc[df["jet1_pt"] > 0, "jet1_pt"].to_numpy()
    if len(j) > 1000:
        h, _ = np.histogram(j, bins=np.linspace(30, 400, 12))
        falling = float((np.diff(h) <= 0).mean())
        rep.add("PASS" if falling >= 0.8 else "WARN",
                f"leading-jet pt spectrum falls in {100*falling:.0f}% of bins (expect mostly falling)")
    mm = df.loc[df["dimuon_mass"] > 0, "dimuon_mass"].to_numpy()
    if len(mm) >= 300:
        peak = ((mm > 81) & (mm < 101)).sum()
        side = ((mm > 60) & (mm < 80)).sum() + ((mm > 102) & (mm < 120)).sum()
        ratio = peak / max(side / 2.0, 1.0)          # sidebands cover 2x the window width... roughly
        rep.data["z_peak_over_sideband"] = float(ratio)
        rep.add("PASS" if ratio > 1.5 else "WARN",
                f"dimuon mass: {peak} events in the Z window vs {side} in sidebands "
                f"(ratio {ratio:.1f}; a muon dataset should show a clear Z peak)")
    else:
        rep.add("WARN", f"only {len(mm)} dimuon events, Z-peak check skipped")

    # 5. scoring sanity
    if score:
        from scipy.stats import spearmanr
        from .models import AutoEncoder, IForest

        data = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
        half = len(data) // 2
        a, b = data.iloc[:half], data.iloc[half:]
        prep = Preprocessor().fit(a)
        Xa, Xb = prep.transform(a), prep.transform(b)
        for name, model in [("isolation_forest", IForest(n_estimators=200, seed=seed)),
                            ("autoencoder", AutoEncoder(epochs=25, seed=seed))]:
            model.fit(Xa, Xval=Xb) if name == "autoencoder" else model.fit(Xa)
            s = model.score(Xb)
            if not np.isfinite(s).all():
                rep.add("FAIL", f"{name}: non-finite scores")
                continue
            rho = spearmanr(s, b["ht"].to_numpy() + b["met"].to_numpy()).correlation
            top = s >= np.quantile(s, 0.99)
            med_ht, top_ht = float(b["ht"].median()), float(b.loc[top, "ht"].median())
            rep.data[f"score_{name}"] = {"spearman_with_ht_plus_met": float(rho),
                                         "median_ht_all": med_ht, "median_ht_flagged": top_ht}
            ok = top_ht > med_ht
            rep.add("PASS" if ok else "WARN",
                    f"{name}: scores finite; flagged top-1% events have median HT {top_ht:.0f} GeV "
                    f"vs {med_ht:.0f} overall (rank corr with HT+MET {rho:+.2f})")
    return rep


def main(argv=None):
    ap = argparse.ArgumentParser(description="sanity checks for a NanoAOD file")
    ap.add_argument("file")
    ap.add_argument("--tree", default="Events")
    ap.add_argument("--max-events", type=int, default=100000)
    ap.add_argument("--score", action="store_true", help="also fit + score with the models")
    ap.add_argument("--report", default="nanoaod_check_report.json")
    args = ap.parse_args(argv)

    rep = check_file(args.file, args.tree, args.max_events, args.score)
    with open(args.report, "w") as f:
        json.dump({"file": args.file, "checks": rep.lines, **rep.data}, f, indent=2, default=str)
    print(f"report written to {args.report}")
    return 1 if rep.failed else 0


if __name__ == "__main__":
    sys.exit(main())
