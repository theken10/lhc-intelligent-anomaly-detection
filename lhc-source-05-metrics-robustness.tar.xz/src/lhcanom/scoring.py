import numpy as np


class ScoreScaler:
    """
    Raw scores from different models aren't comparable (AE gives mse, IF gives
    something around 0.4-0.8, xgb gives a probability). This maps a raw score
    to 0-1 using the empirical CDF of scores on a reference set, so 0.99 means
    "higher than 99% of the reference events".
    """

    def __init__(self):
        self.ref = None

    def fit(self, ref_scores):
        self.ref = np.sort(np.asarray(ref_scores))
        return self

    def __call__(self, s):
        return np.searchsorted(self.ref, s, side="right") / len(self.ref)
