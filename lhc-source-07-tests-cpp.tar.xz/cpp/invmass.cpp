// Small standalone tool: reads "pt1 eta1 phi1 pt2 eta2 phi2" lines from stdin
// and prints the invariant mass of the pair (massless approximation).
// Used in tests/test_cpp.py to cross-check the python implementation.
//
// build:  g++ -O2 -o cpp/invmass cpp/invmass.cpp
#include <cmath>
#include <cstdio>
#include <iostream>

int main() {
    double pt1, eta1, phi1, pt2, eta2, phi2;
    std::cout.precision(10);
    while (std::cin >> pt1 >> eta1 >> phi1 >> pt2 >> eta2 >> phi2) {
        double m2 = 2.0 * pt1 * pt2 * (std::cosh(eta1 - eta2) - std::cos(phi1 - phi2));
        if (m2 < 0) m2 = 0;
        std::cout << std::sqrt(m2) << "\n";
    }
    return 0;
}
