"""
Write synthetic events into a NanoAOD-style ROOT file, read them back through the real
loader and compare with the feature table made directly. Also run the file checker on it,
and on a broken file. This exercises jagged collections, empty events and the checker,
but it is still a stand-in for a real CMS file.
"""
import numpy as np
import pytest

ak = pytest.importorskip("awkward")
uproot = pytest.importorskip("uproot")

from lhcanom import ingest, nanoaod_check, synth


@pytest.fixture(scope="module")
def root_file(tmp_path_factory):
    path = str(tmp_path_factory.mktemp("nano") / "synthetic_nano.root")
    ev, _, _ = synth.build_events(4000, 0.02, seed=5, kinds=synth.SEEN_KINDS + synth.UNSEEN_KINDS)
    expected = synth.to_table(ev)
    with uproot.recreate(path) as f:
        f["Events"] = synth.to_nanoaod_arrays(ev)
    return path, expected


def test_loader_matches_direct_table(root_file):
    path, expected = root_file
    got = ingest.load_nanoaod([path])
    assert len(got) == len(expected)
    for col in ["n_jets", "jet1_pt", "jet2_pt", "jet1_eta", "ht", "met", "n_muons", "mu1_pt",
                "mu2_pt", "n_electrons", "dijet_mass", "dimuon_mass"]:
        np.testing.assert_allclose(got[col].to_numpy(), expected[col].to_numpy(),
                                   rtol=1e-5, atol=1e-4, err_msg=col)


def test_checker_passes_on_good_file(root_file, tmp_path):
    path, _ = root_file
    rep = nanoaod_check.check_file(path, score=True)
    assert not rep.failed
    assert rep.data["events_read"] == 4000
    assert rep.data["empty_collection_fractions"]["no_muons"] > 0.5


def test_checker_fails_on_missing_branch(tmp_path):
    p = str(tmp_path / "bad.root")
    with uproot.recreate(p) as f:
        f["Events"] = {"MET_pt": np.array([1.0, 2.0])}
    rep = nanoaod_check.check_file(p)
    assert rep.failed
    with pytest.raises(KeyError):
        ingest.load_nanoaod([p])


def test_checker_fails_on_wrong_tree(root_file):
    rep = nanoaod_check.check_file(root_file[0], tree="Runs")
    assert rep.failed
