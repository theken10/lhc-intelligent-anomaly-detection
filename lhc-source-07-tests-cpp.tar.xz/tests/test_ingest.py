"""build a tiny NanoAOD-like root file and make sure the loader reads it"""
import numpy as np
import pytest

ak = pytest.importorskip("awkward")

uproot = pytest.importorskip("uproot")

from lhcanom import ingest
from lhcanom.preprocess import FEATURES


def _fake_events(path):
    jet_pt = ak.Array([[100.0, 60.0, 20.0], [45.0], [], [300.0, 250.0, 40.0, 35.0]])
    jet_eta = ak.Array([[0.1, -0.2, 1.0], [0.5], [], [0.0, 0.1, 2.0, -3.0]])
    jet_phi = ak.Array([[0.0, 3.0, 1.0], [1.0], [], [0.5, -2.6, 1.0, 0.0]])
    mu_pt = ak.Array([[30.0, 25.0], [], [10.0], []])
    mu_eta = ak.Array([[0.1, -0.1], [], [0.3], []])
    mu_phi = ak.Array([[0.0, 3.0], [], [1.0], []])
    el_pt = ak.Array([[], [22.0], [], []])
    with uproot.recreate(path) as f:
        f["Events"] = {
            "nJet": ak.num(jet_pt),
            "Jet_pt": jet_pt, "Jet_eta": jet_eta, "Jet_phi": jet_phi,
            "MET_pt": np.array([10.0, 20.0, 5.0, 80.0]),
            "Muon_pt": mu_pt, "Muon_eta": mu_eta, "Muon_phi": mu_phi,
            "Electron_pt": el_pt,
        }


def test_load_nanoaod(tmp_path):
    p = str(tmp_path / "fake.root")
    _fake_events(p)
    df = ingest.load_nanoaod([p])
    assert len(df) == 4
    assert all(c in df.columns for c in FEATURES)
    # jet pt cut at 30 -> event 0 has 2 jets, event 2 has none
    assert df["n_jets"].tolist() == [2, 1, 0, 4]
    assert df["n_muons"].tolist() == [2, 0, 0, 0]   # 10 GeV muon is below cut
    assert df["n_electrons"].tolist() == [0, 1, 0, 0]
    assert df["ht"].iloc[0] == pytest.approx(160.0)
    assert df["dijet_mass"].iloc[1] == 0.0
    assert df["dimuon_mass"].iloc[0] > 0


def test_max_events(tmp_path):
    p = str(tmp_path / "fake.root")
    _fake_events(p)
    assert len(ingest.load_nanoaod([p], max_events=2)) == 2


def test_no_files():
    with pytest.raises(FileNotFoundError):
        ingest.load_nanoaod(["/nonexistent/*.root"])
