import shutil
import subprocess

import numpy as np
import pytest

from lhcanom.kinematics import inv_mass


@pytest.mark.skipif(shutil.which("g++") is None, reason="no g++")
def test_cpp_matches_python(tmp_path):
    exe = str(tmp_path / "invmass")
    subprocess.run(["g++", "-O2", "-o", exe, "cpp/invmass.cpp"], check=True)
    rng = np.random.default_rng(1)
    v = np.column_stack([rng.uniform(20, 500, 50), rng.normal(0, 1.5, 50), rng.uniform(-3, 3, 50),
                         rng.uniform(20, 500, 50), rng.normal(0, 1.5, 50), rng.uniform(-3, 3, 50)])
    inp = "\n".join(" ".join(f"{x:.9f}" for x in row) for row in v)
    out = subprocess.run([exe], input=inp, capture_output=True, text=True, check=True).stdout.split()
    cpp = np.array(out, dtype=float)
    py = inv_mass(*v.T)
    np.testing.assert_allclose(cpp, py, rtol=1e-6)
