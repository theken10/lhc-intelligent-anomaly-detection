import numpy as np
import pandas as pd
import pytest

from lhcanom import synth
from lhcanom.kinematics import inv_mass
from lhcanom.metrics import threshold_at_fpr
from lhcanom.models import AutoEncoder, IForest, XGB
from lhcanom.preprocess import FEATURES, Preprocessor, split, validate
from lhcanom.scoring import ScoreScaler


@pytest.fixture(scope="module")
def data():
    return synth.generate(6000, 0.02, seed=3)


def test_synth_shape_and_labels(data):
    assert len(data) == 6000
    assert data["label"].sum() == 120
    assert all(c in data.columns for c in FEATURES)
    assert (data["jet1_pt"] >= data["jet2_pt"]).all()


def test_inv_mass_back_to_back():
    # two 50 GeV objects at 90 deg apart in phi, same eta -> m = sqrt(2*50*50) = 70.7
    m = inv_mass(50, 0, 0, 50, 0, np.pi / 2)
    assert m == pytest.approx(np.sqrt(2) * 50, rel=1e-9)


def test_validate_drops_bad_rows(data):
    bad = data.copy()
    bad.loc[0, "met"] = np.nan
    bad.loc[1, "jet1_pt"] = -5
    bad.loc[2, "jet1_eta"] = 9.0
    clean, rep = validate(bad)
    assert rep["rows_dropped"] == 3
    assert len(clean) == len(data) - 3


def test_validate_missing_column(data):
    with pytest.raises(ValueError):
        validate(data.drop(columns=["ht"]))


def test_split_is_stratified(data):
    tr, va, te = split(data, 0.6, 0.2, seed=1)
    assert len(tr) + len(va) + len(te) == len(data)
    assert abs(tr["label"].mean() - te["label"].mean()) < 0.01


def test_preprocessor_scaling(data):
    p = Preprocessor().fit(data)
    X = p.transform(data)
    assert X.shape == (len(data), len(FEATURES))
    assert np.abs(X.mean(0)).max() < 1e-3
    assert np.isfinite(X).all()


def test_models_rank_anomalies_above_chance(data):
    from sklearn.metrics import roc_auc_score
    tr, va, te = split(data, 0.6, 0.2, seed=1)
    p = Preprocessor().fit(tr)
    Xtr, Xva, Xte = p.transform(tr), p.transform(va), p.transform(te)
    iso = IForest(n_estimators=100, max_samples=512).fit(Xtr)
    ae = AutoEncoder(epochs=5).fit(Xtr, Xval=Xva)
    xgb = XGB(n_estimators=50).fit(Xtr, tr["label"].to_numpy(), Xva, va["label"].to_numpy())
    for m in (iso, ae, xgb):
        assert roc_auc_score(te["label"], m.score(Xte)) > 0.75, m.name


def test_threshold_gives_requested_rate():
    s = np.random.default_rng(0).normal(size=100000)
    thr = threshold_at_fpr(s, 0.01)
    assert (s >= thr).mean() == pytest.approx(0.01, abs=0.001)


def test_score_scaler_monotone():
    ref = np.random.default_rng(0).exponential(size=5000)
    sc = ScoreScaler().fit(ref)
    out = sc(np.array([0.0, 1.0, 5.0, 100.0]))
    assert np.all(np.diff(out) >= 0)
    assert out[-1] == 1.0
