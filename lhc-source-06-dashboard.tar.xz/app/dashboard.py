import json
import os
import sys

import numpy as np
import pandas as pd
import streamlit as st
from sklearn.metrics import roc_curve

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
RES = os.environ.get("LHC_RESULTS", os.path.join(ROOT, "results"))

st.set_page_config(page_title="LHC anomaly detection", layout="wide")


@st.cache_data
def load_csv(name):
    p = os.path.join(RES, name)
    return pd.read_csv(p) if os.path.exists(p) else None


def load_info():
    p = os.path.join(RES, "run_info.json")
    return json.load(open(p)) if os.path.exists(p) else None


info = load_info()
scores = load_csv("scores_test.csv")
if info is None or scores is None:
    st.error(f"No results found in {RES}. Run `python run_pipeline.py` first.")
    st.stop()

models = [c[len("score_"):] for c in scores.columns if c.startswith("score_")]
has_labels = info["has_labels"]

st.title("LHC event anomaly detection")
if info["source"] == "synthetic":
    st.warning("These results come from SYNTHETIC events, not real CMS data. "
               "Numbers show that the pipeline works, not physics performance.")
st.caption(f"test events: {info['n_test']:,}  |  source: {info['source']}  |  "
           f"cuda available: {info['cuda_available']}")

tab_over, tab_scores, tab_models, tab_explain, tab_perf, tab_rob = st.tabs(
    ["Event statistics", "Anomaly scores", "Model comparison", "Explanations",
     "Performance", "Robustness"])

# ---------------------------------------------------------------- statistics
with tab_over:
    c1, c2, c3 = st.columns(3)
    c1.metric("Events (test split)", f"{len(scores):,}")
    if has_labels:
        c2.metric("Injected anomalies", int(scores["label"].sum()))
    c3.metric("Events dropped in validation", info["validation_report"]["rows_dropped"])

    feat = st.selectbox("Feature", [c for c in scores.columns
                                    if c in ["jet1_pt", "jet2_pt", "ht", "met", "dijet_mass",
                                             "dimuon_mass", "n_jets", "mu1_pt", "n_muons"]])
    logy = st.checkbox("log y axis", value=True)
    x = scores[feat]
    x = x[x > 0] if feat not in ("n_jets", "n_muons") else x
    hist, edges = np.histogram(x, bins=60, range=(float(x.min()), float(np.percentile(x, 99.8))))
    h = pd.DataFrame({"count": hist}, index=np.round(edges[:-1], 1))
    if logy:
        h["count"] = np.log10(h["count"].clip(lower=1))
        st.caption("y axis is log10(count)")
    st.bar_chart(h)
    st.dataframe(scores[["ht", "met", "jet1_pt", "dijet_mass", "dimuon_mass"]].describe().T)
    for fig in ["eda_energy.png", "eda_correlation.png"]:
        p = os.path.join(RES, "figures", fig)
        if os.path.exists(p):
            st.image(p)

# ------------------------------------------------------------------ scores
with tab_scores:
    m = st.selectbox("Model", models, key="score_model")
    col = f"norm_{m}"
    cut = st.slider("Flag events above this percentile score", 0.90, 0.9999, 0.99, 0.0005,
                    format="%.4f")
    flagged = scores[scores[col] >= cut]
    a, b, c = st.columns(3)
    a.metric("Flagged events", f"{len(flagged):,}")
    b.metric("Flag rate", f"{100 * len(flagged) / len(scores):.2f}%")
    if has_labels:
        prec = flagged["label"].mean() if len(flagged) else 0
        rec = flagged["label"].sum() / max(scores["label"].sum(), 1)
        c.metric("Precision / recall", f"{prec:.2f} / {rec:.2f}")

    # score distribution, normal vs anomaly
    bins = np.linspace(0, 1, 41)
    dist = pd.DataFrame({"events": np.histogram(scores[col], bins=bins)[0]}, index=bins[:-1].round(3))
    if has_labels:
        dist["injected anomalies"] = np.histogram(scores.loc[scores.label == 1, col], bins=bins)[0]
    st.bar_chart(dist)
    show = ["event_id", col, "ht", "met", "jet1_pt", "dijet_mass", "dimuon_mass", "n_jets"]
    if has_labels:
        show.append("kind")
    st.dataframe(flagged.sort_values(col, ascending=False)[show].head(200), width="stretch")

# ------------------------------------------------------------------ models
with tab_models:
    met = load_csv("metrics.csv")
    if met is None:
        st.info("No labels in this run, so no supervised metrics.")
    else:
        st.dataframe(met.set_index("model").round(4), width="stretch")
        st.caption("Threshold: unsupervised models flag the top 1% of validation scores (no labels used). "
                   "XGBoost is supervised and trained on the labels of the training split.")
        roc = {}
        for mname in models:
            fpr, tpr, _ = roc_curve(scores["label"], scores[f"score_{mname}"])
            grid = np.linspace(0, 1, 201)
            roc[mname] = np.interp(grid, fpr, tpr)
        st.line_chart(pd.DataFrame(roc, index=np.linspace(0, 1, 201)))
        st.caption("ROC curves (x: false positive rate, y: true positive rate)")
        if has_labels:
            kinds = scores[scores.label == 1].groupby("kind")[[f"flag_{k}" for k in models]].mean()
            kinds.columns = models
            st.subheader("Recall by anomaly type")
            st.dataframe(kinds.round(3))
    curve = load_csv("ae_training_curve.csv")
    if curve is not None:
        st.subheader("Autoencoder training curve")
        st.line_chart(curve.set_index("epoch")[["train_loss", "val_loss"]])

# -------------------------------------------------------------- explanations
with tab_explain:
    ex = load_csv("explanations.csv")
    imp = os.path.join(RES, "figures", "shap_importance.png")
    if os.path.exists(imp):
        st.image(imp)
    if os.path.exists(os.path.join(RES, "figures", "shap_xgboost.png")):
        st.image(os.path.join(RES, "figures", "shap_xgboost.png"))
    if ex is not None:
        st.subheader("Why were the top events flagged?")
        st.caption("z = feature value after log + standard scaling. AE column: features with the "
                   "biggest reconstruction error. IF column: features with the most negative SHAP value.")
        st.dataframe(ex, width="stretch")

# --------------------------------------------------------------- performance
with tab_perf:
    inf = load_csv("benchmark_inference.csv")
    if inf is None:
        st.info("Run the pipeline without --skip-benchmark.")
    else:
        st.subheader("Inference latency / throughput")
        st.caption("Measured on the machine that ran the pipeline, offline, python. "
                   "This says nothing about hardware trigger latency.")
        st.dataframe(inf.round(2), width="stretch")
        piv = inf.pivot(index="batch_size", columns="model", values="events_per_sec")
        st.line_chart(piv)
        st.caption("events per second vs batch size")
    g = load_csv("benchmark_cpu_gpu.csv")
    if g is not None:
        st.subheader("Autoencoder: CPU vs GPU")
        if set(g["device"]) == {"cpu"}:
            st.caption("No CUDA device was available in this run, only CPU was measured.")
        st.dataframe(g.round(2), width="stretch")
    d = load_csv("benchmark_dataset_size.csv")
    if d is not None:
        st.subheader("Dataset size")
        st.dataframe(d.round(3), width="stretch")
        st.line_chart(d.pivot(index="train_size", columns="model", values="roc_auc"))
        st.line_chart(d.pivot(index="train_size", columns="model", values="fit_seconds"))

# ---------------------------------------------------------------- robustness
with tab_rob:
    rob = load_csv("robustness.csv")
    if rob is None:
        st.info("Robustness needs labelled events.")
    else:
        st.caption("Toy drifts applied to the feature table (not a detector simulation). "
                   "fixed = cut chosen on nominal validation data; recal = cut re-chosen from a "
                   "label-free calibration batch of the shifted data (top 1%).")
        kind = st.radio("Shift", ["jes", "pileup"], horizontal=True)
        r = rob[(rob["shift"] == kind) | (rob["shift"] == "none")].copy()
        r["value"] = r["value"].where(r["shift"] != "none", 1.0 if kind == "jes" else 0.0)
        r = r.sort_values("value")
        st.write("ROC-AUC")
        st.line_chart(r.pivot_table(index="value", columns="model", values="roc_auc"))
        st.write("Fraction of normal events flagged with the FIXED cut (design value 1%)")
        st.line_chart(r.pivot_table(index="value", columns="model", values="normal_flag_rate_fixed"))
        st.write("Recall with fixed cut vs re-calibrated cut")
        a, b = st.columns(2)
        a.line_chart(r.pivot_table(index="value", columns="model", values="recall_fixed"))
        b.line_chart(r.pivot_table(index="value", columns="model", values="recall_recal"))
        st.write("Label-free drift alarm (overall flag rate > 1.5x nominal)")
        st.dataframe(r.pivot_table(index="value", columns="model", values="drift_alarm"), width="stretch")
        st.dataframe(r.round(4), width="stretch")

    exp_dir = os.path.join(RES, "experiments")
    if os.path.isdir(exp_dir):
        st.subheader("Generalisation and contamination experiments (5 seeds)")
        for img in ["generalisation.png", "contamination.png"]:
            if os.path.exists(os.path.join(exp_dir, img)):
                st.image(os.path.join(exp_dir, img))
        for name in ["generalisation_summary.csv", "per_kind_auc.csv", "contamination_summary.csv"]:
            p = os.path.join(exp_dir, name)
            if os.path.exists(p):
                st.write(name)
                st.dataframe(pd.read_csv(p), width="stretch")
