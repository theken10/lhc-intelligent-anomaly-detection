import numpy as np


def inv_mass(pt1, eta1, phi1, pt2, eta2, phi2):
    """invariant mass of two massless objects"""
    m2 = 2.0 * pt1 * pt2 * (np.cosh(eta1 - eta2) - np.cos(phi1 - phi2))
    return np.sqrt(np.clip(m2, 0.0, None))


def wrap_phi(phi):
    return (phi + np.pi) % (2 * np.pi) - np.pi
