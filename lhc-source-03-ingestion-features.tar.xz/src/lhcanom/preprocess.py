import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

FEATURES = [
    "n_jets", "jet1_pt", "jet1_eta", "jet2_pt", "jet2_eta", "ht", "met",
    "n_muons", "mu1_pt", "mu1_eta", "mu2_pt", "n_electrons",
    "dijet_mass", "dimuon_mass",
]

# these span orders of magnitude so we take log1p before scaling
LOG_COLS = ["jet1_pt", "jet2_pt", "ht", "met", "mu1_pt", "mu2_pt", "dijet_mass", "dimuon_mass"]


def validate(df):
    """drop broken rows, return (clean_df, report)"""
    report = {"rows_in": len(df)}
    missing = [c for c in FEATURES if c not in df.columns]
    if missing:
        raise ValueError(f"missing columns: {missing}")

    feats = df[FEATURES].replace([np.inf, -np.inf], np.nan)
    bad_nan = feats.isna().any(axis=1)

    pt_cols = [c for c in FEATURES if c.endswith("_pt")] + ["ht", "met"]
    bad_neg = (df[pt_cols] < 0).any(axis=1)
    eta_cols = [c for c in FEATURES if c.endswith("_eta")]
    bad_eta = (df[eta_cols].abs() > 5.0).any(axis=1)

    bad = bad_nan | bad_neg | bad_eta
    report.update(nan_or_inf=int(bad_nan.sum()), negative_pt=int(bad_neg.sum()),
                  eta_out_of_range=int(bad_eta.sum()), rows_dropped=int(bad.sum()))
    clean = df.loc[~bad].reset_index(drop=True)
    report["rows_out"] = len(clean)
    return clean, report


class Preprocessor:
    def __init__(self):
        self.scaler = StandardScaler()

    def _prep(self, df):
        x = df[FEATURES].copy()
        for c in LOG_COLS:
            x[c] = np.log1p(x[c].clip(lower=0))
        return x.to_numpy(dtype=np.float64)

    def fit(self, df):
        self.scaler.fit(self._prep(df))
        return self

    def transform(self, df):
        return self.scaler.transform(self._prep(df)).astype(np.float32)


def split(df, train=0.6, val=0.2, seed=0):
    strat = df["label"] if df["label"].nunique() > 1 else None
    tr, rest = train_test_split(df, train_size=train, random_state=seed, stratify=strat)
    strat = rest["label"] if strat is not None else None
    va_frac = val / (1 - train)
    va, te = train_test_split(rest, train_size=va_frac, random_state=seed, stratify=strat)
    return tr.reset_index(drop=True), va.reset_index(drop=True), te.reset_index(drop=True)
