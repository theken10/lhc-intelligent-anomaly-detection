"""
Reading events. Two sources:
  - real CMS NanoAOD files from the CERN Open Data Portal (via uproot)
  - the synthetic generator (for dev / when you have no files yet)

Both end up as the same flat pandas table so the rest of the code doesn't care.
"""
import glob

import numpy as np
import pandas as pd

from .kinematics import inv_mass
from . import synth

# NanoAOD branch names, these are the standard ones
BRANCHES = [
    "nJet", "Jet_pt", "Jet_eta", "Jet_phi",
    "MET_pt",
    "Muon_pt", "Muon_eta", "Muon_phi",
    "Electron_pt",
]

JET_PT_MIN = 30.0
MUON_PT_MIN = 20.0
ELE_PT_MIN = 20.0


def _first_two(arr):
    import awkward as ak
    """pad a jagged array to at least 2 entries (fill 0) and return the first two as numpy"""
    padded = ak.fill_none(ak.pad_none(arr, 2, clip=True), 0.0)
    return ak.to_numpy(padded[:, 0]), ak.to_numpy(padded[:, 1])


def build_features(ev):
    """awkward record array of NanoAOD events -> flat dataframe"""
    import awkward as ak
    jet_ok = (ev["Jet_pt"] >= JET_PT_MIN) & (abs(ev["Jet_eta"]) < 4.7)
    jpt, jeta, jphi = ev["Jet_pt"][jet_ok], ev["Jet_eta"][jet_ok], ev["Jet_phi"][jet_ok]

    mu_ok = ev["Muon_pt"] >= MUON_PT_MIN
    mpt, meta, mphi = ev["Muon_pt"][mu_ok], ev["Muon_eta"][mu_ok], ev["Muon_phi"][mu_ok]

    el_ok = ev["Electron_pt"] >= ELE_PT_MIN

    j1pt, j2pt = _first_two(jpt)
    j1eta, j2eta = _first_two(jeta)
    j1phi, j2phi = _first_two(jphi)
    m1pt, m2pt = _first_two(mpt)
    m1eta, m2eta = _first_two(meta)
    m1phi, m2phi = _first_two(mphi)

    df = pd.DataFrame({
        "n_jets": ak.to_numpy(ak.num(jpt)),
        "jet1_pt": j1pt, "jet1_eta": j1eta, "jet1_phi": j1phi,
        "jet2_pt": j2pt, "jet2_eta": j2eta, "jet2_phi": j2phi,
        "ht": ak.to_numpy(ak.sum(jpt, axis=1)),
        "met": ak.to_numpy(ev["MET_pt"]),
        "n_muons": ak.to_numpy(ak.num(mpt)),
        "mu1_pt": m1pt, "mu1_eta": m1eta,
        "mu2_pt": m2pt, "mu2_eta": m2eta,
        "n_electrons": ak.to_numpy(ak.sum(el_ok, axis=1)),
    })
    df["dijet_mass"] = np.where(j2pt > 0, inv_mass(j1pt, j1eta, j1phi, j2pt, j2eta, j2phi), 0.0)
    df["dimuon_mass"] = np.where(m2pt > 0, inv_mass(m1pt, m1eta, m1phi, m2pt, m2eta, m2phi), 0.0)
    return df


def load_nanoaod(files, tree="Events", max_events=None):
    import uproot

    paths = []
    for f in files:
        # allow globs, leave xrootd urls alone
        paths += sorted(glob.glob(f)) if "://" not in f else [f]
    if not paths:
        raise FileNotFoundError(f"no input files matched: {files}")

    chunks, got = [], 0
    for p in paths:
        stop = None if max_events is None else max_events - got
        if stop is not None and stop <= 0:
            break
        with uproot.open(p) as fh:
            if tree not in fh:
                raise KeyError(f"{p}: no tree called '{tree}' (found: {fh.keys()[:5]})")
            have = set(fh[tree].keys())
            missing = [b for b in BRANCHES if b not in have]
            if missing:
                raise KeyError(f"{p}: missing branches {missing}. Is this a NanoAOD file?")
            ev = fh[tree].arrays(BRANCHES, entry_stop=stop, library="ak")
        chunks.append(build_features(ev))
        got += len(chunks[-1])
        print(f"read {len(chunks[-1])} events from {p}")
    return pd.concat(chunks, ignore_index=True)


def load_events(cfg):
    """entry point used by the pipeline"""
    if cfg["source"] == "synthetic":
        s = cfg["synthetic"]
        return synth.generate(s["n_events"], s["anomaly_fraction"], seed=cfg["seed"],
                              min_strength=s.get("min_strength", 0.15))
    if cfg["source"] == "nanoaod":
        n = cfg["nanoaod"]
        df = load_nanoaod(n["files"], n.get("tree", "Events"), n.get("max_events"))
        # real data has no truth labels
        df["label"] = -1
        df["kind"] = "unlabelled"
        return df
    raise ValueError(f"unknown source {cfg['source']}")
