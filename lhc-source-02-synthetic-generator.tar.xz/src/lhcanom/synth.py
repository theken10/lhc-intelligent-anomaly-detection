"""
Fake collision events for development, tests and the demo.

Not real physics. Normal events have a falling pt spectrum; anomalies are
normal-looking events pushed towards something odd by a random "strength".
Strength is drawn per event (min_strength..1), so a lot of the weak anomalies
sit inside the tails of the normal distributions and are genuinely hard to
separate. Labels exist ONLY so we can score the models afterwards.

Anomaly categories
  seen   : heavy_dijet, met_lepton, high_multiplicity, dimuon_resonance
  unseen : dijet_met, lepton_ht      (used to test generalisation to new kinds)
"""
import numpy as np
import pandas as pd

from .kinematics import inv_mass, wrap_phi

SEEN_KINDS = ["heavy_dijet", "met_lepton", "high_multiplicity", "dimuon_resonance"]
UNSEEN_KINDS = ["dijet_met", "lepton_ht"]
ANOMALY_KINDS = SEEN_KINDS            # kept for old imports
MAX_JETS = 12

DEFAULT_PARAMS = {
    "jet_pt_scale": 42.0,    # exponential slope of jet pt above 30 GeV
    "jet_mult_mean": 2.2,    # extra jets ~ Poisson(mean)
    "met_scale": 22.0,
    "muon_frac_two": 0.08,
    "z_fraction": 0.45,
}


def _jets(rng, n, p):
    pt = np.zeros((n, MAX_JETS))
    eta = np.zeros((n, MAX_JETS))
    phi = np.zeros((n, MAX_JETS))
    nj = np.clip(1 + rng.poisson(p["jet_mult_mean"], n), 1, MAX_JETS)
    for i in range(MAX_JETS):
        has = nj > i
        pt[:, i] = np.where(has, 30 + rng.exponential(p["jet_pt_scale"] / (1 + 0.35 * i), n), 0)
        eta[:, i] = np.where(has, np.clip(rng.normal(0, 1.5, n), -4.69, 4.69), 0)
        phi[:, i] = np.where(has, rng.uniform(-np.pi, np.pi, n), 0)
    return _sort_jets(pt, eta, phi) + (nj,)


def _sort_jets(pt, eta, phi):
    order = np.argsort(-pt, axis=1)
    return (np.take_along_axis(pt, order, 1), np.take_along_axis(eta, order, 1),
            np.take_along_axis(phi, order, 1))


def _background(rng, n, p):
    jpt, jeta, jphi, nj = _jets(rng, n, p)
    met = rng.rayleigh(p["met_scale"], n) + 0.03 * jpt.sum(1) * rng.random(n)

    p2 = p["muon_frac_two"]
    nmu = rng.choice([0, 1, 2], size=n, p=[0.80 - p2, 0.20, p2])
    mu_pt = np.zeros((n, 2))
    mu_eta = np.zeros((n, 2))
    mu_phi = np.zeros((n, 2))
    for k in range(2):
        has = nmu > k
        mu_pt[:, k] = np.where(has, 20 + rng.exponential(18 / (1 + 0.5 * k), n), 0)
        mu_eta[:, k] = np.where(has, np.clip(rng.normal(0, 1.2, n), -2.4, 2.4), 0)
        mu_phi[:, k] = np.where(has, rng.uniform(-np.pi, np.pi, n), 0)

    # a fraction of dimuon events are Z -> mumu, built from the mass
    isz = (nmu == 2) & (rng.random(n) < p["z_fraction"])
    if isz.any():
        m = rng.normal(91.2, 3.0, isz.sum())
        deta = mu_eta[isz, 0] - mu_eta[isz, 1]
        dphi = mu_phi[isz, 0] - mu_phi[isz, 1]
        pt2 = m**2 / (2 * mu_pt[isz, 0] * (np.cosh(deta) - np.cos(dphi)) + 1e-6)
        mu_pt[isz, 1] = np.clip(pt2, 20, 400)

    nel = rng.choice([0, 1, 2], size=n, p=[0.85, 0.12, 0.03])
    return dict(jpt=jpt, jeta=jeta, jphi=jphi, nj=nj, met=met, nmu=nmu,
                mu_pt=mu_pt, mu_eta=mu_eta, mu_phi=mu_phi, nel=nel)


def _blend(old, target, s):
    return old + s * (target - old)


def _set_muon(ev, idx, slot, pt, eta, phi):
    ev["mu_pt"][idx, slot] = np.maximum(pt, 20.0)
    ev["mu_eta"][idx, slot] = np.clip(eta, -2.4, 2.4)
    ev["mu_phi"][idx, slot] = phi


def _make_anomalies(rng, ev, idx, kind, s):
    """push events `idx` towards anomaly `kind` by strength s (array, 0..1)"""
    m = len(idx)
    if m == 0:
        return
    if kind in ("heavy_dijet", "dijet_met"):
        target = rng.normal(750, 90, m).clip(300, None) if kind == "heavy_dijet" \
            else rng.normal(230, 40, m).clip(120, None)
        j1 = np.maximum(ev["jpt"][idx, 0], 30)
        j2 = np.maximum(ev["jpt"][idx, 1], 30)
        ev["jpt"][idx, 0] = _blend(j1, target, s)
        ev["jpt"][idx, 1] = _blend(j2, target * rng.uniform(0.8, 1.0, m), s)
        ev["nj"][idx] = np.maximum(ev["nj"][idx], 2)
        for k in (0, 1):
            ev["jeta"][idx, k] = ev["jeta"][idx, k] * (1 - 0.6 * s)
        pt, eta, phi = _sort_jets(ev["jpt"][idx], ev["jeta"][idx], ev["jphi"][idx])
        ev["jpt"][idx], ev["jeta"][idx], ev["jphi"][idx] = pt, eta, phi
        if kind == "heavy_dijet":
            back = rng.random(m) < s          # stronger -> more likely back to back
            ev["jphi"][idx[back], 1] = wrap_phi(ev["jphi"][idx[back], 0] + np.pi +
                                                rng.normal(0, 0.1, back.sum()))
        else:
            ev["met"][idx] = _blend(ev["met"][idx], rng.normal(180, 40, m).clip(80, None), s)
    elif kind == "met_lepton":
        ev["met"][idx] = _blend(ev["met"][idx], rng.normal(320, 70, m).clip(150, None), s)
        old = ev["mu_pt"][idx, 0]
        ev["nmu"][idx] = np.maximum(ev["nmu"][idx], 1)
        _set_muon(ev, idx, 0, _blend(np.maximum(old, 20), rng.normal(260, 50, m).clip(100, None), s),
                  rng.normal(0, 0.9, m), rng.uniform(-np.pi, np.pi, m))
    elif kind == "lepton_ht":
        ev["nmu"][idx] = np.maximum(ev["nmu"][idx], 1)
        old = np.maximum(ev["mu_pt"][idx, 0], 20)
        _set_muon(ev, idx, 0, _blend(old, rng.normal(140, 30, m).clip(60, None), s),
                  rng.normal(0, 1.0, m), rng.uniform(-np.pi, np.pi, m))
        _extra_jets(rng, ev, idx, s, target_n=rng.integers(5, 8, m), scale_hi=70)
    elif kind == "high_multiplicity":
        _extra_jets(rng, ev, idx, s, target_n=rng.integers(8, 13, m), scale_hi=95)
    elif kind == "dimuon_resonance":
        mass = _blend(rng.uniform(60, 150, m), rng.uniform(450, 900, m), s)
        ev["nmu"][idx] = 2
        pt1 = np.maximum(rng.normal(mass / 2.3, 25, m), 25)
        deta = rng.normal(0, 0.8, m)
        dphi = np.pi - np.abs(rng.normal(0, 0.3, m))
        eta1 = rng.normal(0, 0.8, m)
        phi1 = rng.uniform(-np.pi, np.pi, m)
        ev["mu_pt"][idx, 0] = pt1
        ev["mu_eta"][idx, 0] = eta1
        ev["mu_phi"][idx, 0] = phi1
        ev["mu_eta"][idx, 1] = eta1 - deta
        ev["mu_phi"][idx, 1] = wrap_phi(phi1 + dphi)
        ev["mu_pt"][idx, 1] = np.maximum(mass**2 / (2 * pt1 * (np.cosh(deta) - np.cos(dphi))), 20)
    else:
        raise ValueError(kind)


def _extra_jets(rng, ev, idx, s, target_n, scale_hi):
    m = len(idx)
    nj = np.clip(np.round(_blend(ev["nj"][idx].astype(float), target_n, s)).astype(int), 1, MAX_JETS)
    pt = np.zeros((m, MAX_JETS))
    eta = np.zeros((m, MAX_JETS))
    phi = np.zeros((m, MAX_JETS))
    for i in range(MAX_JETS):
        has = nj > i
        scale = 42 / (1 + 0.35 * i) + s * scale_hi
        pt[:, i] = np.where(has, 30 + rng.exponential(scale, m), 0)
        eta[:, i] = np.where(has, np.clip(rng.normal(0, 1.3, m), -4.69, 4.69), 0)
        phi[:, i] = np.where(has, rng.uniform(-np.pi, np.pi, m), 0)
    pt, eta, phi = _sort_jets(pt, eta, phi)
    ev["jpt"][idx], ev["jeta"][idx], ev["jphi"][idx], ev["nj"][idx] = pt, eta, phi, nj


def to_table(ev):
    jpt, jeta, jphi = ev["jpt"], ev["jeta"], ev["jphi"]
    mu_pt, mu_eta, mu_phi = ev["mu_pt"], ev["mu_eta"], ev["mu_phi"]
    df = pd.DataFrame({
        "n_jets": ev["nj"].astype(int),
        "jet1_pt": jpt[:, 0], "jet1_eta": jeta[:, 0], "jet1_phi": jphi[:, 0],
        "jet2_pt": jpt[:, 1], "jet2_eta": jeta[:, 1], "jet2_phi": jphi[:, 1],
        "ht": jpt.sum(1),
        "met": ev["met"],
        "n_muons": ev["nmu"].astype(int),
        "mu1_pt": mu_pt[:, 0], "mu1_eta": mu_eta[:, 0],
        "mu2_pt": mu_pt[:, 1], "mu2_eta": mu_eta[:, 1],
        "n_electrons": ev["nel"].astype(int),
    })
    both_j = jpt[:, 1] > 0
    df["dijet_mass"] = np.where(both_j, inv_mass(jpt[:, 0], jeta[:, 0], jphi[:, 0],
                                                 jpt[:, 1], jeta[:, 1], jphi[:, 1]), 0.0)
    both_m = (mu_pt[:, 1] > 0) & (mu_pt[:, 0] > 0)
    df["dimuon_mass"] = np.where(both_m, inv_mass(mu_pt[:, 0], mu_eta[:, 0], mu_phi[:, 0],
                                                  mu_pt[:, 1], mu_eta[:, 1], mu_phi[:, 1]), 0.0)
    return df


def build_events(n, anomaly_fraction=0.01, seed=0, kinds=None, min_strength=0.15, params=None):
    """returns (event arrays, label array, kind array)"""
    kinds = list(kinds) if kinds is not None else list(SEEN_KINDS)
    p = {**DEFAULT_PARAMS, **(params or {})}
    rng = np.random.default_rng(seed)
    ev = _background(rng, n, p)

    n_anom = int(round(n * anomaly_fraction))
    label = np.zeros(n, dtype=int)
    kind_col = np.array(["normal"] * n, dtype=object)
    if n_anom and kinds:
        anom_idx = rng.choice(n, size=n_anom, replace=False)
        which = rng.integers(0, len(kinds), n_anom)
        strength = rng.uniform(min_strength, 1.0, n_anom)
        label[anom_idx] = 1
        for k, name in enumerate(kinds):
            sel = which == k
            _make_anomalies(rng, ev, anom_idx[sel], name, strength[sel])
            kind_col[anom_idx[sel]] = name
    return ev, label, kind_col


def generate(n, anomaly_fraction=0.01, seed=0, kinds=None, min_strength=0.15, params=None):
    ev, label, kind_col = build_events(n, anomaly_fraction, seed, kinds, min_strength, params)
    df = to_table(ev)
    df["label"] = label
    df["kind"] = kind_col
    return df


def to_nanoaod_arrays(ev):
    """event arrays -> dict of jagged awkward arrays named like NanoAOD (for tests/demos)"""
    import awkward as ak

    def jag(a, mask):
        # keep only the filled slots of each event
        return ak.Array([list(row[m]) for row, m in zip(a, mask)])

    jm = ev["jpt"] > 0
    mm = ev["mu_pt"] > 0
    el = [[30.0] * int(k) for k in ev["nel"]]
    return {
        "nJet": jm.sum(1).astype(np.int32),
        "Jet_pt": jag(ev["jpt"], jm), "Jet_eta": jag(ev["jeta"], jm), "Jet_phi": jag(ev["jphi"], jm),
        "MET_pt": ev["met"],
        "Muon_pt": jag(ev["mu_pt"], mm), "Muon_eta": jag(ev["mu_eta"], mm),
        "Muon_phi": jag(ev["mu_phi"], mm),
        "Electron_pt": ak.Array(el),
    }
